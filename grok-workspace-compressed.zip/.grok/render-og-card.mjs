import { chromium } from "playwright";
import { pathToFileURL } from "node:url";
import path from "node:path";

const html = pathToFileURL(path.resolve("/workspace/.grok/og-card.html")).href;
const out = "/workspace/.grok/og-card.png";

const browser = await chromium.launch({ args: ["--disable-web-security"] });
const page = await browser.newPage({
  viewport: { width: 1200, height: 630 },
  deviceScaleFactor: 2,
});
await page.goto(html, { waitUntil: "networkidle" });
await page.waitForTimeout(200);
await page.screenshot({ path: out, type: "png" });
await browser.close();
console.log("wrote", out);
