import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import {
  ArrowUpRight,
  BookOpen,
  Mail,
  PenLine,
  Quote,
} from "lucide-react";
import {
  FAQ,
  RECEIVE,
  SERVICE_OPTIONS,
  SERVICES,
  STEPS,
  STUDIO,
  WORK,
  type WorkSample,
} from "@/lib/site-content";

export const Route = createFileRoute("/")({ component: Home });

function BookMark({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      viewBox="0 0 32 32"
      width="32"
      height="32"
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="6" fill="#5f7f64" />
      <path fill="#faf7f0" d="M4 10l12-3 12 3v14L16 27 4 24V10z" />
      <path fill="#3f5a44" d="M15 8.2h2v17.6h-2z" />
      <path
        fill="#3f5a44"
        d="M9 23V12h3.2L16 18l3.8-6H23v11h-2.4v-6.4L16 22.2l-4.6-5.6V23z"
      />
    </svg>
  );
}

function Home() {
  const [navOpen, setNavOpen] = useState(false);
  const [activeWork, setActiveWork] = useState<WorkSample | null>(null);
  const closeNav = () => setNavOpen(false);

  return (
    <div className="site">
      <div className="stage" aria-hidden="true">
        <div className="aurora" />
        <div className="glow glow-a" />
        <div className="glow glow-b" />
        <div className="glow glow-c" />
        <div className="glow glow-d" />
        <div className="sparkle" />
        <div className="sheen" />
        <div className="grain" />
      </div>
      <header className="header">
        <div className="container header-inner">
          <a href="#top" className="logo" onClick={closeNav}>
            <BookMark className="logo-mark" />
            <span>manuscriptedits</span>
          </a>
          <nav className={navOpen ? "nav open" : "nav"}>
            <a href="#about" onClick={closeNav}>
              About
            </a>
            <a href="#services" onClick={closeNav}>
              Services
            </a>
            <a href="#work" onClick={closeNav}>
              Work
            </a>
            <a href="#approach" onClick={closeNav}>
              Approach
            </a>
            <a href="#contact" className="nav-cta" onClick={closeNav}>
              Enquire
            </a>
          </nav>
          <button
            className={navOpen ? "nav-toggle open" : "nav-toggle"}
            aria-label={navOpen ? "Close menu" : "Open menu"}
            aria-expanded={navOpen}
            onClick={() => setNavOpen((o) => !o)}
          >
            <span />
            <span />
            <span />
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <div className="container hero-grid">
          <div className="hero-copy">
            <p className="kicker reveal reveal-1">Beta reading studio</p>
            <h1 className="reveal reveal-2">
              See your story the way a careful reader will.
            </h1>
            <p className="hero-subtext reveal reveal-3">
              Honest notes. Kind delivery. Your voice stays yours.
            </p>
            <div className="hero-actions reveal reveal-4">
              <a href="#work" className="btn btn-primary">
                View selected work
              </a>
              <a href="#contact" className="btn btn-ghost">
                Start a conversation
              </a>
            </div>
            <p className="hero-meta reveal reveal-5">
              {STUDIO.genres.join(" · ")}
            </p>
          </div>
          <div className="hero-art reveal reveal-3">
            <figure className="desk-frame">
              <img
                src="/images/studio-desk-v2.jpg"
                alt="Overhead view of a wooden desk with printed manuscript pages, a green pencil, and a cup of coffee"
                width={1200}
                height={900}
              />
              <figcaption>
                <PenLine size={14} aria-hidden="true" />
                Working pages, marked in the margin
              </figcaption>
            </figure>
          </div>
        </div>
      </section>

      <section id="about" className="section about">
        <div className="container about-grid">
          <div className="about-media">
            <figure className="portrait-frame">
              <div className="about-shot">
                <img
                  className="about-portrait"
                  src="/images/hero-banner.jpg"
                  alt="Sunlit linen table with an open handwritten journal and dried flowers"
                  width={1280}
                  height={720}
                />
                <div className="about-lockup">
                  <p className="about-lockup-name">manuscriptedits</p>
                  <p className="about-lockup-tag">Thoughtful Beta Reading</p>
                </div>
              </div>
            </figure>
            <p className="about-caption">Reader first. Editor second.</p>
          </div>
          <div className="about-body">
            <p className="kicker">The studio</p>
            <h2>I read the way authors hope someone will.</h2>
            <blockquote className="about-quote">
              <Quote size={22} aria-hidden="true" />
              <span>
                A conversation with the manuscript, not a red pen across it.
              </span>
            </blockquote>
            <p>
              Every manuscript deserves a careful reader. Someone who sits with
              the story, notices what already works, and names what could be
              stronger.
            </p>
            <p>
              My notes are honest and never harsh. I track emotional impact,
              character depth, pacing, and the quiet places where a story can
              breathe. Fantasy, literary fiction, memoir, romance: the job is
              the same. Protect the voice. Sharpen the work.
            </p>
          </div>
        </div>
      </section>

      <section id="services" className="section services">
        <div className="container">
          <div className="section-head">
            <p className="kicker">What I offer</p>
            <h2>Four ways to work together</h2>
          </div>
          <ol className="service-list">
            {SERVICES.map((s) => (
              <li key={s.num} className="service-row">
                <span className="service-num">{s.num}</span>
                <div>
                  <h3>{s.title}</h3>
                  <p>{s.body}</p>
                </div>
              </li>
            ))}
          </ol>
          <div className="receive">
            <p className="kicker">What you receive</p>
            <div className="receive-grid">
              {RECEIVE.map((item) => (
                <article key={item.title} className="receive-card">
                  <h3>{item.title}</h3>
                  <p>{item.body}</p>
                </article>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section id="work" className="section work">
        <div className="container">
          <div className="section-head">
            <p className="kicker">Selected work</p>
            <h2>Recent manuscripts</h2>
            <p className="section-lead">
              Titles stay with their authors. What I can share is the shape of
              the notes, the kind of seeing I bring to a page.
            </p>
          </div>
          <div className="work-stack">
            {WORK.map((project) => (
              <article className="work-card" key={project.num}>
                <div className="work-index">
                  <span>{project.num}</span>
                  <span className="work-tag">{project.tag}</span>
                </div>
                <div className="work-body">
                  <h3>{project.title}</h3>
                  <p className="work-focus">{project.focus}</p>
                  <ul className="work-notes">
                    {project.notes.map((note) => (
                      <li key={note}>{note}</li>
                    ))}
                  </ul>
                  <button
                    type="button"
                    className="text-link"
                    onClick={() => setActiveWork(project)}
                  >
                    {project.letterKind === "inline"
                      ? "Read sample comments"
                      : "Read a sample letter"}
                    <ArrowUpRight size={16} aria-hidden="true" />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="approach" className="section approach">
        <div className="container">
          <div className="section-head">
            <p className="kicker">How I work</p>
            <h2>Slow reading. Clear notes.</h2>
          </div>
          <div className="steps">
            {STEPS.map((step) => (
              <article className="step" key={step.num}>
                <span className="step-num">{step.num}</span>
                <h3>{step.title}</h3>
                <p>{step.body}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="section faq">
        <div className="container faq-grid">
          <div className="section-head">
            <p className="kicker">Before you write</p>
            <h2>Practical questions</h2>
          </div>
          <div className="faq-list">
            {FAQ.map((item) => (
              <details key={item.q} className="faq-item">
                <summary>{item.q}</summary>
                <p>{item.a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="section contact">
        <div className="container contact-panel">
          <div>
            <p className="kicker kicker-on-dark">Available for new manuscripts</p>
            <h2>Send the pages when you are ready.</h2>
            <p>
              Tell me the genre, the length, and what you most want eyes on. I
              will write back with fit, timing, and a quote.
            </p>
            <div className="contact-links">
              <a href={`mailto:${STUDIO.email}`} className="contact-row">
                <span>Email</span>
                <strong>{STUDIO.email}</strong>
              </a>
              <a
                href={STUDIO.instagram.href}
                target="_blank"
                rel="noopener noreferrer"
                className="contact-row"
              >
                <span>Instagram</span>
                <strong>{STUDIO.instagram.handle}</strong>
              </a>
              <a
                href={STUDIO.tiktok.href}
                target="_blank"
                rel="noopener noreferrer"
                className="contact-row"
              >
                <span>TikTok</span>
                <strong>{STUDIO.tiktok.handle}</strong>
              </a>
            </div>
          </div>
          <EnquireForm />
        </div>
      </section>

      <footer className="footer">
        <div className="container footer-inner">
          <span className="footer-brand">
            <BookOpen size={16} aria-hidden="true" />
            manuscriptedits
          </span>
          <span>Thoughtful beta reading for authors</span>
        </div>
      </footer>

      <SampleLetter work={activeWork} onClose={() => setActiveWork(null)} />
    </div>
  );
}

function EnquireForm() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const data = new FormData(event.currentTarget);
    const name = String(data.get("name") ?? "").trim();
    const email = String(data.get("email") ?? "").trim();
    const genre = String(data.get("genre") ?? "").trim();
    const words = String(data.get("words") ?? "").trim();
    const service = String(data.get("service") ?? "").trim();
    const message = String(data.get("message") ?? "").trim();

    if (!name || !email || !genre || !message) {
      setError("Name, email, genre, and a short note are required.");
      return;
    }

    const body = [
      `Name: ${name}`,
      `Email: ${email}`,
      `Genre: ${genre}`,
      words ? `Word count: ${words}` : null,
      service ? `Service: ${service}` : null,
      "",
      message,
    ]
      .filter((line) => line !== null)
      .join("\n");

    const href = `mailto:${STUDIO.email}?subject=${encodeURIComponent(
      `Manuscript enquiry: ${genre}`,
    )}&body=${encodeURIComponent(body)}`;

    window.location.href = href;
    setSent(true);
  }

  if (sent) {
    return (
      <div className="enquire enquire-done" role="status">
        <Mail size={22} aria-hidden="true" />
        <h3>Your mail app should open.</h3>
        <p>
          If it does not, write directly to{" "}
          <a href={`mailto:${STUDIO.email}`}>{STUDIO.email}</a>.
        </p>
        <button type="button" className="btn btn-on-dark" onClick={() => setSent(false)}>
          Write another note
        </button>
      </div>
    );
  }

  return (
    <form className="enquire" onSubmit={onSubmit} noValidate>
      <div className="field-row">
        <label>
          Name
          <input name="name" type="text" autoComplete="name" required suppressHydrationWarning />
        </label>
        <label>
          Email
          <input name="email" type="email" autoComplete="email" required suppressHydrationWarning />
        </label>
      </div>
      <div className="field-row">
        <label>
          Genre
          <input name="genre" type="text" placeholder="Fantasy, memoir…" required suppressHydrationWarning />
        </label>
        <label>
          Word count
          <input name="words" type="text" inputMode="numeric" placeholder="e.g. 82,000" suppressHydrationWarning />
        </label>
      </div>
      <label>
        Service
        <select name="service" defaultValue="Not sure yet" suppressHydrationWarning>
          {SERVICE_OPTIONS.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </label>
      <label>
        What do you want eyes on?
        <textarea
          name="message"
          rows={5}
          required
          placeholder="Where you are in the process, and what you most want a reader to notice."
          suppressHydrationWarning
        />
      </label>
      {error ? <p className="form-error">{error}</p> : null}
      <button type="submit" className="btn btn-on-dark">
        Open an email draft
      </button>
    </form>
  );
}

function SampleLetter({
  work,
  onClose,
}: {
  work: WorkSample | null;
  onClose: () => void;
}) {
  const closeRef = useRef<HTMLButtonElement>(null);
  const titleId = useId();

  useEffect(() => {
    if (!work) return;
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    closeRef.current?.focus();
    function onKey(event: KeyboardEvent) {
      if (event.key === "Escape") onClose();
    }
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = previous;
      document.removeEventListener("keydown", onKey);
    };
  }, [work, onClose]);

  if (!work) return null;

  return (
    <div className="dialog-backdrop" onClick={onClose} role="presentation">
      <div
        className="dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        onClick={(event) => event.stopPropagation()}
      >
        <div className="dialog-bar">
          <p className="kicker">{work.letterKicker}</p>
          <button
            ref={closeRef}
            type="button"
            className="dialog-close"
            onClick={onClose}
          >
            Close
          </button>
        </div>
        <p className="dialog-tag">{work.tag}</p>
        <h2 id={titleId}>{work.letterTitle}</h2>
        <div className={work.letterKind === "inline" ? "letter letter-inline" : "letter"}>
          {work.letter.map((paragraph) => (
            <p key={paragraph}>{paragraph}</p>
          ))}
        </div>
        <p className="dialog-note">
          Shared with names and titles removed. The full letter stays between
          author and reader.
        </p>
      </div>
    </div>
  );
}
