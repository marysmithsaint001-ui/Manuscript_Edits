export const STUDIO = {
  name: "manuscriptedits",
  email: "manuscriptedits.work@gmail.com",
  instagram: {
    handle: "@themanuscriptedit",
    href: "https://www.instagram.com/themanuscriptedit/",
  },
  tiktok: {
    handle: "@manuscriptedits",
    href: "https://www.tiktok.com/@manuscriptedits",
  },
  genres: ["Fantasy", "Literary fiction", "Romance", "Memoir", "Personal non-fiction"],
};

export const SERVICES = [
  {
    num: "01",
    title: "Developmental beta reading",
    body: "Plot, character arcs, pacing, and emotional impact. For when the foundation still needs to hold.",
  },
  {
    num: "02",
    title: "Full manuscript feedback",
    body: "A complete read with both the big picture and chapter-level notes on what lands, what confuses, and what shines.",
  },
  {
    num: "03",
    title: "Inline comments",
    body: "Line-by-line reactions in your document. Clarity, rhythm, and the live feel of a first reader.",
  },
  {
    num: "04",
    title: "Sensitivity notes",
    body: "Careful notes on representation and emotional truth, written with respect for the story you meant to tell.",
  },
];

export type WorkSample = {
  num: string;
  tag: string;
  title: string;
  focus: string;
  notes: string[];
  letterKind: "letter" | "inline";
  letterKicker: string;
  letterTitle: string;
  letter: string[];
};

export const WORK: WorkSample[] = [
  {
    num: "I",
    tag: "Dark fantasy",
    title: "Emotional and structural read",
    focus:
      "Key scenes, character motive, action pacing, and whether the ending felt earned.",
    notes: [
      "The prologue’s violence stayed under the rest of the book.",
      "Quiet rooftop scenes gave the story room to breathe.",
      "One chase sequence ran long and lost tension.",
      "The last confrontation felt empty, not triumphant, and that was right.",
    ],
    letterKind: "letter",
    letterKicker: "Sample overview letter",
    letterTitle: "After the last page",
    letter: [
      "The opening loss sat with me the whole way. I already knew every later choice would be poisoned by that night, and the book never let me forget it.",
      "The quiet meetings on the roof felt real. Those scenes breathed. Then the middle turned the ground over: bodies, ghosts, a sword that carried weight for the rest of the novel.",
      "The rooftop chase went on a long time. By the third or fourth leap I wanted the camera to pull back. A couple of sharp beats inside it still kept me leaning forward.",
      "The last confrontation did not feel like triumph. It felt like emptiness. For this story, that was the honest ending. I finished and the night still felt a little heavy, which means the people who survived are carrying what they should.",
    ],
  },
  {
    num: "II",
    tag: "Personal development",
    title: "Full developmental read",
    focus:
      "Repetition, author voice, chapter structure, and the power of lived stories.",
    notes: [
      "The author’s real life was the book’s strongest asset.",
      "A formal coach-voice kept creating distance.",
      "Two chapters drifted into a second topic mid-way.",
      "The writing jumped when struggle was allowed to stay on the page.",
    ],
    letterKind: "letter",
    letterKicker: "Sample chapter letter",
    letterTitle: "Protect the story you actually lived",
    letter: [
      "The personal history is the reason a reader will trust this book: the childhood dream, the business, the unfulfillment, the return to school later in life. That path is the authority. Keep it close to the skin.",
      "The introduction currently tries to do too much. Frameworks, symbolism, and pep talk stack on top of the story until it reads like several pieces joined together. A strong opening needs four jobs: hook with the life, say who it is for, show why you can speak, and point to the road ahead.",
      "Some of the teaching belongs in its own chapter. Right now it crowds the doorway.",
      "Voice is the other lever. After a vulnerable beat the writing often steps back into coach-and-teacher mode. Let the doubt, the loneliness, the fear of starting over stay on the page a little longer. Readers will follow the takeaway more readily if they have felt the cost.",
    ],
  },
  {
    num: "III",
    tag: "Literary fiction",
    title: "Close developmental and line notes",
    focus:
      "Voice, emotional timing, and keeping the argument inside the characters.",
    notes: [
      "The voice was sharp, precise, and politically awake.",
      "Grief arriving late felt true, not staged.",
      "The argument was strongest when a body, a peach, or a folded towel carried it.",
      "The hidden network plot had room to tighten without losing mystery.",
    ],
    letterKind: "inline",
    letterKicker: "Sample inline comments",
    letterTitle: "Notes in the margin",
    letter: [
      "This line lands like a punch. It sets up the whole wound in one breath. Stay with this theme. It is your strongest thread.",
      "Taking the call anyway tells me everything about the avoidance pattern. Character through action, not explanation. Keep that.",
      "The small physical relief right after the spiral gives us a necessary breath. Keep using that grounding object as a pulse through later chapters.",
      "Ending on relief instead of a fix feels honest. She is not okay. She stopped performing. That is enough for now, and it is a better hook than a speech.",
      "“Done calling survival safety” is a thesis the book has been earning. Now I want to see what she does with the pressure.",
    ],
  },
  {
    num: "IV",
    tag: "Contemporary romance",
    title: "Line-level craft pass",
    focus:
      "Chemistry, character consistency, and letting tension build before the bold move.",
    notes: [
      "Protective rules clashed with earlier careless shoves.",
      "A years-long silence inside one house asked too much of the reader.",
      "The first bold flirtation needed a longer fuse.",
      "A maturity beat landed harder when it was implied, not announced.",
    ],
    letterKind: "inline",
    letterKicker: "Sample inline comments",
    letterTitle: "Where the reader trips",
    letter: [
      "He shoves her in one scene and later enforces a fierce “nobody touches her” rule. Those two actions argue with each other. If the protectiveness is real, it has to show up the first time someone puts hands on her.",
      "Living in the same house with almost no conversation for years feels extreme. Softening to “rarely spoke” keeps the distance without breaking the family physics.",
      "The first blatant flirtation is a jump for someone who has barely spoken to her. The tension works. Give his boldness a quieter dress rehearsal a chapter earlier so the thud becomes a spark.",
      "The on-the-nose maturity line is doing work the scene already did. Hint, then get out of the way.",
    ],
  },
];

export const STEPS = [
  {
    num: "1",
    title: "I read as a reader first",
    body: "Where I leaned in, where I drifted, where I felt something. Not a checklist. A true first encounter.",
  },
  {
    num: "2",
    title: "Then I name the pattern",
    body: "Pacing, motive, structure, voice. The same issue showing up in three chapters is the note that matters.",
  },
  {
    num: "3",
    title: "You keep the pen",
    body: "I do not rewrite your book. I help you see it clearly so you can make it stronger in your own voice.",
  },
];

export const RECEIVE = [
  {
    title: "An overview letter",
    body: "What the book is doing, where it is strong, and the two or three changes that would move it most.",
  },
  {
    title: "Chapter-level notes",
    body: "Scene by scene: what landed, what confused, where the temperature dropped.",
  },
  {
    title: "Inline reactions",
    body: "When you want them: live reader thoughts sitting next to the sentence that caused them.",
  },
];

export const FAQ = [
  {
    q: "What should I send?",
    a: "The manuscript (Word or Google Doc), genre, word count, and what you most want eyes on. A short note on where you are in the process helps. A synopsis is welcome, never required.",
  },
  {
    q: "How long does a read take?",
    a: "Most novels turn around in two to four weeks. I confirm timing before we start so you are not left guessing.",
  },
  {
    q: "Do you rewrite or copyedit?",
    a: "No. I am a careful first reader, not a ghostwriter or a line editor for grammar. I will flag a repeated tic if it gets in the way of the story. The sentences stay yours.",
  },
  {
    q: "How do you quote?",
    a: "Per manuscript, based on length and the kind of notes you need: overview only, full developmental, or inline. Write with the word count and I will send fit, timing, and a quote.",
  },
  {
    q: "What do you read?",
    a: "Fantasy, literary fiction, romance, memoir, and personal non-fiction. If the work is outside that, still write. I will say honestly if I am not the right reader.",
  },
];

export const SERVICE_OPTIONS = [
  "Developmental beta reading",
  "Full manuscript feedback",
  "Inline comments",
  "Sensitivity notes",
  "Not sure yet",
];
