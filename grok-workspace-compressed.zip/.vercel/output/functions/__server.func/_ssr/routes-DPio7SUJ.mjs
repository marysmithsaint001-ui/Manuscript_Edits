import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as BookOpen, i as Mail, n as Quote, o as ArrowUpRight, r as PenLine } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DPio7SUJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var STUDIO = {
	name: "manuscriptedits",
	email: "manuscriptedits.work@gmail.com",
	instagram: {
		handle: "@themanuscriptedit",
		href: "https://www.instagram.com/themanuscriptedit/"
	},
	tiktok: {
		handle: "@manuscriptedits",
		href: "https://www.tiktok.com/@manuscriptedits"
	},
	genres: [
		"Fantasy",
		"Literary fiction",
		"Romance",
		"Memoir",
		"Personal non-fiction"
	]
};
var SERVICES = [
	{
		num: "01",
		title: "Developmental beta reading",
		body: "Plot, character arcs, pacing, and emotional impact. For when the foundation still needs to hold."
	},
	{
		num: "02",
		title: "Full manuscript feedback",
		body: "A complete read with both the big picture and chapter-level notes on what lands, what confuses, and what shines."
	},
	{
		num: "03",
		title: "Inline comments",
		body: "Line-by-line reactions in your document. Clarity, rhythm, and the live feel of a first reader."
	},
	{
		num: "04",
		title: "Sensitivity notes",
		body: "Careful notes on representation and emotional truth, written with respect for the story you meant to tell."
	}
];
var WORK = [
	{
		num: "I",
		tag: "Dark fantasy",
		title: "Emotional and structural read",
		focus: "Key scenes, character motive, action pacing, and whether the ending felt earned.",
		notes: [
			"The prologue’s violence stayed under the rest of the book.",
			"Quiet rooftop scenes gave the story room to breathe.",
			"One chase sequence ran long and lost tension.",
			"The last confrontation felt empty, not triumphant, and that was right."
		],
		letterKind: "letter",
		letterKicker: "Sample overview letter",
		letterTitle: "After the last page",
		letter: [
			"The opening loss sat with me the whole way. I already knew every later choice would be poisoned by that night, and the book never let me forget it.",
			"The quiet meetings on the roof felt real. Those scenes breathed. Then the middle turned the ground over: bodies, ghosts, a sword that carried weight for the rest of the novel.",
			"The rooftop chase went on a long time. By the third or fourth leap I wanted the camera to pull back. A couple of sharp beats inside it still kept me leaning forward.",
			"The last confrontation did not feel like triumph. It felt like emptiness. For this story, that was the honest ending. I finished and the night still felt a little heavy, which means the people who survived are carrying what they should."
		]
	},
	{
		num: "II",
		tag: "Personal development",
		title: "Full developmental read",
		focus: "Repetition, author voice, chapter structure, and the power of lived stories.",
		notes: [
			"The author’s real life was the book’s strongest asset.",
			"A formal coach-voice kept creating distance.",
			"Two chapters drifted into a second topic mid-way.",
			"The writing jumped when struggle was allowed to stay on the page."
		],
		letterKind: "letter",
		letterKicker: "Sample chapter letter",
		letterTitle: "Protect the story you actually lived",
		letter: [
			"The personal history is the reason a reader will trust this book: the childhood dream, the business, the unfulfillment, the return to school later in life. That path is the authority. Keep it close to the skin.",
			"The introduction currently tries to do too much. Frameworks, symbolism, and pep talk stack on top of the story until it reads like several pieces joined together. A strong opening needs four jobs: hook with the life, say who it is for, show why you can speak, and point to the road ahead.",
			"Some of the teaching belongs in its own chapter. Right now it crowds the doorway.",
			"Voice is the other lever. After a vulnerable beat the writing often steps back into coach-and-teacher mode. Let the doubt, the loneliness, the fear of starting over stay on the page a little longer. Readers will follow the takeaway more readily if they have felt the cost."
		]
	},
	{
		num: "III",
		tag: "Literary fiction",
		title: "Close developmental and line notes",
		focus: "Voice, emotional timing, and keeping the argument inside the characters.",
		notes: [
			"The voice was sharp, precise, and politically awake.",
			"Grief arriving late felt true, not staged.",
			"The argument was strongest when a body, a peach, or a folded towel carried it.",
			"The hidden network plot had room to tighten without losing mystery."
		],
		letterKind: "inline",
		letterKicker: "Sample inline comments",
		letterTitle: "Notes in the margin",
		letter: [
			"This line lands like a punch. It sets up the whole wound in one breath. Stay with this theme. It is your strongest thread.",
			"Taking the call anyway tells me everything about the avoidance pattern. Character through action, not explanation. Keep that.",
			"The small physical relief right after the spiral gives us a necessary breath. Keep using that grounding object as a pulse through later chapters.",
			"Ending on relief instead of a fix feels honest. She is not okay. She stopped performing. That is enough for now, and it is a better hook than a speech.",
			"“Done calling survival safety” is a thesis the book has been earning. Now I want to see what she does with the pressure."
		]
	},
	{
		num: "IV",
		tag: "Contemporary romance",
		title: "Line-level craft pass",
		focus: "Chemistry, character consistency, and letting tension build before the bold move.",
		notes: [
			"Protective rules clashed with earlier careless shoves.",
			"A years-long silence inside one house asked too much of the reader.",
			"The first bold flirtation needed a longer fuse.",
			"A maturity beat landed harder when it was implied, not announced."
		],
		letterKind: "inline",
		letterKicker: "Sample inline comments",
		letterTitle: "Where the reader trips",
		letter: [
			"He shoves her in one scene and later enforces a fierce “nobody touches her” rule. Those two actions argue with each other. If the protectiveness is real, it has to show up the first time someone puts hands on her.",
			"Living in the same house with almost no conversation for years feels extreme. Softening to “rarely spoke” keeps the distance without breaking the family physics.",
			"The first blatant flirtation is a jump for someone who has barely spoken to her. The tension works. Give his boldness a quieter dress rehearsal a chapter earlier so the thud becomes a spark.",
			"The on-the-nose maturity line is doing work the scene already did. Hint, then get out of the way."
		]
	}
];
var STEPS = [
	{
		num: "1",
		title: "I read as a reader first",
		body: "Where I leaned in, where I drifted, where I felt something. Not a checklist. A true first encounter."
	},
	{
		num: "2",
		title: "Then I name the pattern",
		body: "Pacing, motive, structure, voice. The same issue showing up in three chapters is the note that matters."
	},
	{
		num: "3",
		title: "You keep the pen",
		body: "I do not rewrite your book. I help you see it clearly so you can make it stronger in your own voice."
	}
];
var RECEIVE = [
	{
		title: "An overview letter",
		body: "What the book is doing, where it is strong, and the two or three changes that would move it most."
	},
	{
		title: "Chapter-level notes",
		body: "Scene by scene: what landed, what confused, where the temperature dropped."
	},
	{
		title: "Inline reactions",
		body: "When you want them: live reader thoughts sitting next to the sentence that caused them."
	}
];
var FAQ = [
	{
		q: "What should I send?",
		a: "The manuscript (Word or Google Doc), genre, word count, and what you most want eyes on. A short note on where you are in the process helps. A synopsis is welcome, never required."
	},
	{
		q: "How long does a read take?",
		a: "Most novels turn around in two to four weeks. I confirm timing before we start so you are not left guessing."
	},
	{
		q: "Do you rewrite or copyedit?",
		a: "No. I am a careful first reader, not a ghostwriter or a line editor for grammar. I will flag a repeated tic if it gets in the way of the story. The sentences stay yours."
	},
	{
		q: "How do you quote?",
		a: "Per manuscript, based on length and the kind of notes you need: overview only, full developmental, or inline. Write with the word count and I will send fit, timing, and a quote."
	},
	{
		q: "What do you read?",
		a: "Fantasy, literary fiction, romance, memoir, and personal non-fiction. If the work is outside that, still write. I will say honestly if I am not the right reader."
	}
];
var SERVICE_OPTIONS = [
	"Developmental beta reading",
	"Full manuscript feedback",
	"Inline comments",
	"Sensitivity notes",
	"Not sure yet"
];
function BookMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className,
		viewBox: "0 0 32 32",
		width: "32",
		height: "32",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "6",
				fill: "#5f7f64"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#faf7f0",
				d: "M4 10l12-3 12 3v14L16 27 4 24V10z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#3f5a44",
				d: "M15 8.2h2v17.6h-2z"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "#3f5a44",
				d: "M9 23V12h3.2L16 18l3.8-6H23v11h-2.4v-6.4L16 22.2l-4.6-5.6V23z"
			})
		]
	});
}
function Home() {
	const [navOpen, setNavOpen] = (0, import_react.useState)(false);
	const [activeWork, setActiveWork] = (0, import_react.useState)(null);
	const closeNav = () => setNavOpen(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "site",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "stage",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aurora" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow glow-a" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow glow-b" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow glow-c" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "glow glow-d" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sparkle" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sheen" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "header",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container header-inner",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
							href: "#top",
							className: "logo",
							onClick: closeNav,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookMark, { className: "logo-mark" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "manuscriptedits" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
							className: navOpen ? "nav open" : "nav",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#about",
									onClick: closeNav,
									children: "About"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#services",
									onClick: closeNav,
									children: "Services"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#work",
									onClick: closeNav,
									children: "Work"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#approach",
									onClick: closeNav,
									children: "Approach"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contact",
									className: "nav-cta",
									onClick: closeNav,
									children: "Enquire"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							className: navOpen ? "nav-toggle open" : "nav-toggle",
							"aria-label": navOpen ? "Close menu" : "Open menu",
							"aria-expanded": navOpen,
							onClick: () => setNavOpen((o) => !o),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
							]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "hero",
				id: "top",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "cover",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/images/hero-banner.jpg",
						alt: "Sunlit linen table with an open handwritten journal and dried flowers",
						width: 1280,
						height: 720
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "cover-lockup",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "cover-name",
							children: "manuscriptedits"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "cover-tag",
							children: "Thoughtful Beta Reading"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container hero-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-copy",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker reveal reveal-1",
								children: "Beta reading studio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "reveal reveal-2",
								children: "See your story the way a careful reader will."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hero-subtext reveal reveal-3",
								children: "Honest notes. Kind delivery. Your voice stays yours."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "hero-actions reveal reveal-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#work",
									className: "btn btn-primary",
									children: "View selected work"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contact",
									className: "btn btn-ghost",
									children: "Start a conversation"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "hero-meta reveal reveal-5",
								children: STUDIO.genres.join(" · ")
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "hero-art reveal reveal-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
							className: "desk-frame",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/studio-desk-v2.jpg",
								alt: "Overhead view of a wooden desk with printed manuscript pages, a green pencil, and a cup of coffee",
								width: 1200,
								height: 900
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {
								size: 14,
								"aria-hidden": "true"
							}), "Working pages, marked in the margin"] })]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "about",
				className: "section about",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container about-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "about-media",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figure", {
							className: "portrait-frame",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								className: "about-portrait",
								src: "/images/reader.jpg",
								alt: "Portrait of the manuscriptedits reader, holding a book against a sage wall",
								width: 900,
								height: 1125
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "about-caption",
							children: "Reader first. Editor second."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "about-body",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "The studio"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "I read the way authors hope someone will." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
								className: "about-quote",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quote, {
									size: 22,
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "A conversation with the manuscript, not a red pen across it." })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Every manuscript deserves a careful reader. Someone who sits with the story, notices what already works, and names what could be stronger." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "My notes are honest and never harsh. I track emotional impact, character depth, pacing, and the quiet places where a story can breathe. Fantasy, literary fiction, memoir, romance: the job is the same. Protect the voice. Sharpen the work." })
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "services",
				className: "section services",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "section-head",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "What I offer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Four ways to work together" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "service-list",
							children: SERVICES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "service-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "service-num",
									children: s.num
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: s.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: s.body })] })]
							}, s.num))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "receive",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "What you receive"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "receive-grid",
								children: RECEIVE.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "receive-card",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: item.title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.body })]
								}, item.title))
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "work",
				className: "section work",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "section-head",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker",
								children: "Selected work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Recent manuscripts" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "section-lead",
								children: "Titles stay with their authors. What I can share is the shape of the notes, the kind of seeing I bring to a page."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "work-stack",
						children: WORK.map((project) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "work-card",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "work-index",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: project.num }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "work-tag",
									children: project.tag
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "work-body",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: project.title }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "work-focus",
										children: project.focus
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "work-notes",
										children: project.notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: note }, note))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "text-link",
										onClick: () => setActiveWork(project),
										children: [project.letterKind === "inline" ? "Read sample comments" : "Read a sample letter", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {
											size: 16,
											"aria-hidden": "true"
										})]
									})
								]
							})]
						}, project.num))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "approach",
				className: "section approach",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "section-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "How I work"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Slow reading. Clear notes." })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "steps",
						children: STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "step",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "step-num",
									children: step.num
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: step.title }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: step.body })
							]
						}, step.num))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "faq",
				className: "section faq",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container faq-grid",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "section-head",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "Before you write"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Practical questions" })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "faq-list",
						children: FAQ.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "faq-item",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", { children: item.q }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: item.a })]
						}, item.q))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "contact",
				className: "section contact",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container contact-panel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker kicker-on-dark",
							children: "Available for new manuscripts"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Send the pages when you are ready." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tell me the genre, the length, and what you most want eyes on. I will write back with fit, timing, and a quote." }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "contact-links",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: `mailto:${STUDIO.email}`,
									className: "contact-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Email" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: STUDIO.email })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: STUDIO.instagram.href,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "contact-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Instagram" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: STUDIO.instagram.handle })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: STUDIO.tiktok.href,
									target: "_blank",
									rel: "noopener noreferrer",
									className: "contact-row",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "TikTok" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: STUDIO.tiktok.handle })]
								})
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnquireForm, {})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "footer",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "container footer-inner",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "footer-brand",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, {
							size: 16,
							"aria-hidden": "true"
						}), "manuscriptedits"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Thoughtful beta reading for authors" })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleLetter, {
				work: activeWork,
				onClose: () => setActiveWork(null)
			})
		]
	});
}
function EnquireForm() {
	const [sent, setSent] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	function onSubmit(event) {
		event.preventDefault();
		setError("");
		const data = new FormData(event.currentTarget);
		const name = String(data.get("name") ?? "").trim();
		const email = String(data.get("email") ?? "").trim();
		const genre = String(data.get("genre") ?? "").trim();
		const words = String(data.get("words") ?? "").trim();
		const service = String(data.get("service") ?? "").trim();
		const message = String(data.get("message") ?? "").trim();
		if (!name || !email || !genre || !message) {
			setError("Name, email, genre, and a short note are required.");
			return;
		}
		const body = [
			`Name: ${name}`,
			`Email: ${email}`,
			`Genre: ${genre}`,
			words ? `Word count: ${words}` : null,
			service ? `Service: ${service}` : null,
			"",
			message
		].filter((line) => line !== null).join("\n");
		const href = `mailto:${STUDIO.email}?subject=${encodeURIComponent(`Manuscript enquiry: ${genre}`)}&body=${encodeURIComponent(body)}`;
		window.location.href = href;
		setSent(true);
	}
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "enquire enquire-done",
		role: "status",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, {
				size: 22,
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { children: "Your mail app should open." }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				"If it does not, write directly to",
				" ",
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: `mailto:${STUDIO.email}`,
					children: STUDIO.email
				}),
				"."
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "btn btn-on-dark",
				onClick: () => setSent(false),
				children: "Write another note"
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "enquire",
		onSubmit,
		noValidate: true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "field-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "name",
					type: "text",
					autoComplete: "name",
					required: true,
					suppressHydrationWarning: true
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Email", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "email",
					type: "email",
					autoComplete: "email",
					required: true,
					suppressHydrationWarning: true
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "field-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Genre", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "genre",
					type: "text",
					placeholder: "Fantasy, memoir…",
					required: true,
					suppressHydrationWarning: true
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Word count", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					name: "words",
					type: "text",
					inputMode: "numeric",
					placeholder: "e.g. 82,000",
					suppressHydrationWarning: true
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["Service", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
				name: "service",
				defaultValue: "Not sure yet",
				suppressHydrationWarning: true,
				children: SERVICE_OPTIONS.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: option,
					children: option
				}, option))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", { children: ["What do you want eyes on?", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				name: "message",
				rows: 5,
				required: true,
				placeholder: "Where you are in the process, and what you most want a reader to notice.",
				suppressHydrationWarning: true
			})] }),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "form-error",
				children: error
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "submit",
				className: "btn btn-on-dark",
				children: "Open an email draft"
			})
		]
	});
}
function SampleLetter({ work, onClose }) {
	const closeRef = (0, import_react.useRef)(null);
	const titleId = (0, import_react.useId)();
	(0, import_react.useEffect)(() => {
		if (!work) return;
		const previous = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		closeRef.current?.focus();
		function onKey(event) {
			if (event.key === "Escape") onClose();
		}
		document.addEventListener("keydown", onKey);
		return () => {
			document.body.style.overflow = previous;
			document.removeEventListener("keydown", onKey);
		};
	}, [work, onClose]);
	if (!work) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "dialog-backdrop",
		onClick: onClose,
		role: "presentation",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "dialog",
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": titleId,
			onClick: (event) => event.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dialog-bar",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: work.letterKicker
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						ref: closeRef,
						type: "button",
						className: "dialog-close",
						onClick: onClose,
						children: "Close"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "dialog-tag",
					children: work.tag
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: titleId,
					children: work.letterTitle
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: work.letterKind === "inline" ? "letter letter-inline" : "letter",
					children: work.letter.map((paragraph) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: paragraph }, paragraph))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "dialog-note",
					children: "Shared with names and titles removed. The full letter stays between author and reader."
				})
			]
		})
	});
}
//#endregion
export { Home as component };
